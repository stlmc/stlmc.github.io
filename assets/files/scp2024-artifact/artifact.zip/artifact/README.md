#### Structure of Our Artifact

| Directory | Description |
|------|---|
| 3rd_party | Various tools and software to reproduce our experiments |
| benchmarks | Benchmark models and configurations used for the experiments |
| scripts | Reproduction scripts. Use '-h' for each script for more details |


#### Reproducing the Experiments

**Running the Experiments**

Our artifact contains the scripts to reproduce the experiments of our paper. You can run the experiments of the paper as follows:

* To run the <u>first experiment</u> of the paper. Go to the 'scripts/exp1' directory and use the following command:

  ~~~shell
  user@ubuntu:~/artifact/scripts/exp1$ ./run-exp ../../benchmarks/exp1 -t 3600
  ~~~

  This command reproduces the first experiment with a time out 3600s using the benchmarks in the directory '../../benchmarks/exp1'.

* To run the <u>second experiment</u> of the paper. Go to the 'scripts/exp2' directory and use the following command:

  ~~~shell
  user@ubuntu:~/artifact/scripts/exp2$ ./run-exp ../../benchmarks/exp2 -t 3600
  ~~~

  This command reproduces the experiment using models in '../../benchmarks/exp2'.

*Remark: Each reproduction script creates a 'log' directory and put log files in it.*

**Generating Reports**

You can create a spreadsheet report for each experiment from the log files using the 'gen-report' script in each experiment directory.

For example, you can generate a report file for the first experiment as follows:

~~~shell
user@ubuntu:~/artifact/scripts/exp1$ ./gen-report # generates a report 'exp1-report.csv'
~~~

*Note: Each script generates a report file using the log files in the 'log' directory.*

**Generating HTML Tables**

You can also create an html table from a report file using the 'gen-table' script.

For example, the following command generates an html table 'exp1-table.html' using the 'exp1-report.csv'.

~~~shell
user@ubuntu:~/artifact/scripts/exp1$ ./gen-table # generates a table 'exp1-table.html'
~~~